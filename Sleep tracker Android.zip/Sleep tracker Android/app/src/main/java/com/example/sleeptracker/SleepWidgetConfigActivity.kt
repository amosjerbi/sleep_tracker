package com.example.sleeptracker

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class SleepWidgetConfigActivity : AppCompatActivity() {
    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Set dialog window properties
        window.setBackgroundDrawableResource(android.R.color.transparent)
        window.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        
        // Set the result to CANCELED. This will cause the widget host to cancel
        // out of the widget placement if they press the back button.
        setResult(RESULT_CANCELED)
        
        setContentView(R.layout.activity_sleep_widget_config)
        
        // Find the widget ID from the intent.
        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        
        // If they gave us an intent without the widget ID, just bail.
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        
        // Load current wakeup time
        val prefs = getSharedPreferences(SleepWidget.PREFS_NAME, MODE_PRIVATE)
        val currentTime = prefs.getString(SleepWidget.PREF_WAKEUP_TIME, SleepWidget.DEFAULT_WAKEUP_TIME)
            ?.let { LocalTime.parse(it) }
            ?: LocalTime.parse(SleepWidget.DEFAULT_WAKEUP_TIME)
        
        // Set up the time picker
        val timePicker = findViewById<TimePicker>(R.id.time_picker).apply {
            setIs24HourView(true)
            hour = currentTime.hour
            minute = currentTime.minute
        }
        
        // Handle the save button
        findViewById<Button>(R.id.save_button).setOnClickListener {
            val newTime = LocalTime.of(timePicker.hour, timePicker.minute)
            val timeStr = newTime.format(DateTimeFormatter.ofPattern("HH:mm"))
            
            // Save the wakeup time
            prefs.edit().putString(SleepWidget.PREF_WAKEUP_TIME, timeStr).apply()
            
            // Update the widget
            val appWidgetManager = AppWidgetManager.getInstance(this)
            SleepWidget.updateAppWidget(this, appWidgetManager, appWidgetId)
            
            // Make sure we pass back the original appWidgetId
            val resultValue = Intent().apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            }
            setResult(Activity.RESULT_OK, resultValue)
            finish()
        }
    }
}
