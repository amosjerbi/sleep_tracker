package com.example.sleeptracker

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import java.time.LocalTime
import java.time.temporal.ChronoUnit
import java.time.format.DateTimeFormatter
import android.app.PendingIntent
import android.content.Intent
import android.os.Build

class SleepWidget : AppWidgetProvider() {
    
    companion object {
        const val PREFS_NAME = "com.example.sleeptracker.SleepWidget"
        const val PREF_WAKEUP_TIME = "wakeup_time"
        const val DEFAULT_WAKEUP_TIME = "07:00"
        
        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val wakeupTimeStr = prefs.getString(PREF_WAKEUP_TIME, DEFAULT_WAKEUP_TIME) ?: DEFAULT_WAKEUP_TIME
            
            val views = RemoteViews(context.packageName, R.layout.sleep_widget)
            
            // Calculate time until wakeup
            val now = LocalTime.now()
            val wakeupTime = LocalTime.parse(wakeupTimeStr)
            var minutesUntilWakeup = ChronoUnit.MINUTES.between(now, wakeupTime)
            if (minutesUntilWakeup < 0) {
                minutesUntilWakeup += 24 * 60 // Add 24 hours if wakeup time is tomorrow
            }
            
            // Update progress and time display
            val hoursUntilWakeup = minutesUntilWakeup / 60
            val remainingMinutes = minutesUntilWakeup % 60
            val progress = ((minutesUntilWakeup.toFloat() / (24 * 60)) * 100).toInt()
            
            views.setTextViewText(R.id.wakeup_time, "Wake up at ${wakeupTime.format(DateTimeFormatter.ofPattern("HH:mm"))}")
            views.setTextViewText(R.id.hours_text, "${hoursUntilWakeup}h")
            views.setTextViewText(R.id.minutes_text, "${remainingMinutes}m")
            views.setProgressBar(R.id.sleep_progress, 100, progress, false)
            
            // Add click intent to open config activity
            val intent = Intent(context, SleepWidgetConfigActivity::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                appWidgetId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_container, pendingIntent)
            
            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        // Initialize default wakeup time if not set
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (!prefs.contains(PREF_WAKEUP_TIME)) {
            prefs.edit().putString(PREF_WAKEUP_TIME, DEFAULT_WAKEUP_TIME).apply()
        }
    }
}
