package com.example.sleeptracker

import android.app.AppOpsManager
import android.app.PendingIntent
import android.app.usage.UsageStatsManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Process
import android.provider.Settings
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class SleepWidget : AppWidgetProvider() {

    companion object {
        private const val ACTION_REFRESH = "com.example.sleeptracker.action.REFRESH"
        const val PREFS_NAME = "com.example.sleeptracker.SleepWidget"
        const val PREF_WAKEUP_TIME = "wakeup_time"
        const val DEFAULT_WAKEUP_TIME = "07:00"

        private const val PREF_STEP_BASELINE = "step_baseline"
        private const val PREF_STEP_DAY = "step_day"
        private const val PREF_STEP_LAST = "step_last"
        private const val METERS_PER_STEP = 0.762
        private const val KCAL_PER_STEP = 0.04

        private data class UsageRow(val appName: String, val durationMs: Long)

        fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(context.packageName, R.layout.sleep_widget)

            val steps = getTodaySteps(context)
            val header = if (steps == null) {
                "Steps unavailable"
            } else {
                val kcal = (steps * KCAL_PER_STEP).toInt()
                val km = (steps * METERS_PER_STEP) / 1000.0
                "${formatSteps(steps)} steps • ${kcal} kcal • ${formatKm(km)} km"
            }
            views.setTextViewText(R.id.header_text, header)

            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val wakeupTimeStr = prefs.getString(PREF_WAKEUP_TIME, DEFAULT_WAKEUP_TIME) ?: DEFAULT_WAKEUP_TIME
            val wakeupTime = runCatching { LocalTime.parse(wakeupTimeStr) }
                .getOrElse { LocalTime.parse(DEFAULT_WAKEUP_TIME) }
            val now = LocalTime.now()
            var minutesUntilWakeup = ChronoUnit.MINUTES.between(now, wakeupTime)
            if (minutesUntilWakeup < 0) minutesUntilWakeup += 24 * 60

            views.setTextViewText(R.id.sleep_value, formatDurationFromMinutes(minutesUntilWakeup))
            views.setTextViewText(
                R.id.sleep_subtitle,
                "Wake up ${wakeupTime.format(DateTimeFormatter.ofPattern("HH:mm"))}"
            )

            val configIntent = Intent(context, SleepWidgetConfigActivity::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            }
            val configPendingIntent = PendingIntent.getActivity(
                context,
                appWidgetId + 3000,
                configIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.sleep_panel, configPendingIntent)

            val refreshIntent = Intent(context, SleepWidget::class.java).apply { action = ACTION_REFRESH }
            val refreshPendingIntent = PendingIntent.getBroadcast(
                context,
                appWidgetId,
                refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.refresh_button, refreshPendingIntent)

            if (!hasUsageStatsPermission(context)) {
                views.setTextViewText(R.id.screen_value, "Enable")
                views.setTextViewText(R.id.screen_subtitle, "Grant Usage Access")
                val permissionIntent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                val permissionPendingIntent = PendingIntent.getActivity(
                    context,
                    appWidgetId + 10000,
                    permissionIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.screen_panel, permissionPendingIntent)
            } else {
                val usageRows = getTodayUsageRows(context)
                val totalMs = usageRows.sumOf { it.durationMs }
                views.setTextViewText(R.id.screen_value, formatDuration(totalMs))
                val topRow = usageRows.firstOrNull()
                val topLabel = if (topRow == null) "No usage yet"
                else "Top: ${topRow.appName} ${formatShortDuration(topRow.durationMs)}"
                views.setTextViewText(R.id.screen_subtitle, topLabel)
            }

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        private fun getTodaySteps(context: Context): Int? {
            val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return null

            val latch = CountDownLatch(1)
            var reading: Int? = null
            val listener = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent) {
                    reading = event.values.firstOrNull()?.toInt()
                    latch.countDown()
                }

                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
            }

            sensorManager.registerListener(listener, stepSensor, SensorManager.SENSOR_DELAY_NORMAL)
            latch.await(2, TimeUnit.SECONDS)
            sensorManager.unregisterListener(listener)

            val current = reading ?: return getCachedSteps(context)
            return storeAndComputeTodaySteps(context, current)
        }

        private fun storeAndComputeTodaySteps(context: Context, currentTotalSinceBoot: Int): Int {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val today = LocalDate.now().toEpochDay()
            val savedDay = prefs.getLong(PREF_STEP_DAY, Long.MIN_VALUE)
            var baseline = prefs.getInt(PREF_STEP_BASELINE, -1)

            if (savedDay != today || baseline < 0) {
                baseline = currentTotalSinceBoot
                prefs.edit()
                    .putLong(PREF_STEP_DAY, today)
                    .putInt(PREF_STEP_BASELINE, baseline)
                    .putInt(PREF_STEP_LAST, 0)
                    .apply()
                return 0
            }

            if (currentTotalSinceBoot < baseline) {
                baseline = currentTotalSinceBoot
                prefs.edit().putInt(PREF_STEP_BASELINE, baseline).apply()
            }

            val stepsToday = (currentTotalSinceBoot - baseline).coerceAtLeast(0)
            prefs.edit().putInt(PREF_STEP_LAST, stepsToday).apply()
            return stepsToday
        }

        private fun getCachedSteps(context: Context): Int? {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val today = LocalDate.now().toEpochDay()
            val savedDay = prefs.getLong(PREF_STEP_DAY, Long.MIN_VALUE)
            if (savedDay != today) return 0
            return prefs.getInt(PREF_STEP_LAST, 0)
        }

        private fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, SleepWidget::class.java))
            for (id in ids) {
                updateAppWidget(context, manager, id)
            }
        }

        private fun hasUsageStatsPermission(context: Context): Boolean {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val uid = context.applicationInfo.uid
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    uid,
                    context.packageName
                )
            } else {
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            }

            if (mode == AppOpsManager.MODE_ALLOWED) return true
            return canReadUsageStats(context)
        }

        private fun canReadUsageStats(context: Context): Boolean {
            val usageStatsManager =
                context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val sixHoursAgo = now - TimeUnit.HOURS.toMillis(6)
            val stats = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                sixHoursAgo,
                now
            )
            return !stats.isNullOrEmpty()
        }

        private fun getTodayUsageRows(context: Context): List<UsageRow> {
            val usageStatsManager =
                context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val startOfDay = LocalDate.now().atStartOfDay().atZone(java.time.ZoneId.systemDefault())
                .toInstant().toEpochMilli()
            val now = System.currentTimeMillis()

            val usageStats = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                startOfDay,
                now
            )

            val aggregated = mutableMapOf<String, Long>()
            for (stat in usageStats) {
                if (stat.packageName == context.packageName) continue
                val duration = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    maxOf(stat.totalTimeVisible, stat.totalTimeInForeground)
                } else {
                    stat.totalTimeInForeground
                }
                if (duration > 0) {
                    aggregated[stat.packageName] = (aggregated[stat.packageName] ?: 0L) + duration
                }
            }

            return aggregated.entries
                .sortedByDescending { it.value }
                .take(3)
                .map { entry ->
                    val appName = try {
                        val info = context.packageManager.getApplicationInfo(entry.key, 0)
                        context.packageManager.getApplicationLabel(info).toString()
                    } catch (_: Exception) {
                        entry.key.substringAfterLast('.')
                    }
                    UsageRow(appName, entry.value)
                }
        }

        private fun formatDuration(durationMs: Long): String {
            val totalMinutes = durationMs / 60000
            val hours = totalMinutes / 60
            val minutes = totalMinutes % 60
            return "${hours}h ${minutes}m"
        }

        private fun formatDurationFromMinutes(totalMinutes: Long): String {
            val hours = totalMinutes / 60
            val minutes = totalMinutes % 60
            return "${hours}h ${minutes}m"
        }

        private fun formatShortDuration(durationMs: Long): String {
            val totalMinutes = durationMs / 60000
            val hours = totalMinutes / 60
            val minutes = totalMinutes % 60
            return if (hours > 0) "${hours}h" else "${minutes}m"
        }

        private fun formatSteps(steps: Int): String {
            return "%,d".format(steps)
        }

        private fun formatKm(km: Double): String {
            return String.format("%.1f", km)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            updateAllWidgets(context)
        }
    }
}
